$(document).ready(function() { 
	$(".lightbox-image").append("<span></span>");
	$(".lightbox-image span").css({opacity:1});
		
});