$(document).ready(function() { 

	/*************** tooltips  ****************/
	$(".list-services a.tooltips").easyTooltip();
	
}); 