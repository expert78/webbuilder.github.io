Cufon.replace('.menu li, .text-5', { fontFamily: 'Vegur', hover:true });
Cufon.replace('h3, h4, .text-6', { fontFamily: 'Vegur 400', hover:true });
Cufon.replace('.text-1', { fontFamily: 'Vegur',textShadow: '#191919 1px 1px', hover:true });
Cufon.replace('.text-2', { fontFamily: 'Vegur 400',textShadow: '#191919 1px 1px', hover:true });
Cufon.replace('.text-3', { fontFamily: 'Vegur',textShadow: '#4f9dd1 1px 1px', hover:true });
Cufon.replace('.text-4', { fontFamily: 'Vegur 400',textShadow: '#4f9dd1 1px 1px', hover:true });